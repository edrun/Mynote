#!/bin/bash
getmail -v -n -r ~/.getmail/getmailrc.gmail -r ~/.getmail/getmailrc.sina
