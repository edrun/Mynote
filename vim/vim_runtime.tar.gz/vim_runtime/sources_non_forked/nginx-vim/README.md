# nginx syntax files for Vim.

Copied into a directory to play well with pathogen.

* Original: http://www.vim.org/scripts/script.php?script_id=1886


